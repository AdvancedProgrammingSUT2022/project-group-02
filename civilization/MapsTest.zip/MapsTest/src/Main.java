public class Main {
    public static void main(String[] args){
        Map map = new Map();
        map.fillMap();
        map.printMapBoard();
    }
}
