public class Technology {
}
