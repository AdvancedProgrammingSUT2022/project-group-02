public class PhysicalObject {
}
